import torch
from flask import Flask, request, jsonify
from models.RawNet3 import RawNet3, Bottle2neck
from pytube import YouTube
from pydub import AudioSegment
from train import predict
import os


app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True


model_path = r".\models\ckpts\best_1_bak.pth"
weights = torch.load(model_path, map_location=torch.device("cuda:0"))
# load model with nOut = 2 (2 classes, fake or real)
model = RawNet3(
    Bottle2neck,
    model_scale=8,
    context=True,
    summed=True,
    nOut=2,
    encoder_type="ECA",
    log_sinc=True,
    norm_sinc="mean",
    out_bn=False,
    sinc_stride=10
)
model.load_state_dict(weights)
model.to("cuda:0")

@app.route("/", methods=["POST", "GET"])
def index():
    if request.method == "GET":
        url = request.form.get("URL")
        yt = YouTube(url)
        video_stream = yt.streams.get_highest_resolution()
        tmp_path = video_stream.download(output_path = ".", filename="temp.mp4")
        audio = AudioSegment.from_file(tmp_path, "mp4")
        audio_path = "./temp.mp3"
        audio.export(audio_path, format="mp3")
        pred, real_prob = predict(model, audio_path)
        data = {
            "status": 200,
            "fake_prob": 1 - real_prob
        }
        os.remove(audio_path)
        os.remove(tmp_path)
        return jsonify(data)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)