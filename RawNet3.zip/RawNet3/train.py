import torch
import torch.nn as nn
import torch.optim as optim
import librosa
import numpy as np
import os

from models.RawNet3 import RawNet3
from models.RawNetBasicBlock import Bottle2neck
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from tqdm import tqdm


SAMPLE_RATE = 16000  # Hz
DURATION = 10  # seconds
SAMPLES_PER_AUDIO = SAMPLE_RATE * DURATION
BATCH_SIZE = 2
NUM_WORKERS = 1
NUM_EPOCHS = 20


def load_audio(file_path, sample_rate=SAMPLE_RATE, duration=DURATION):
    audio, sr = librosa.load(file_path, sr=sample_rate, duration=duration)
    if len(audio) < SAMPLES_PER_AUDIO:
        padding = SAMPLES_PER_AUDIO - len(audio)
        audio = np.pad(audio, (0, padding), 'constant')
    else:
        audio = audio[:SAMPLES_PER_AUDIO]
    return audio


class ASVspoofDataset(Dataset):

    def __init__(self, file_paths, labels, transform=None):
        self.file_paths = file_paths
        self.labels = labels  # 0 for real, 1 for fake
        self.transform = transform

    def __len__(self):
        return len(self.file_paths)

    def __getitem__(self, idx):
        audio = load_audio(self.file_paths[idx])
        label = self.labels[idx]
        if self.transform:
            audio = self.transform(audio)
        return torch.tensor(audio, dtype=torch.float32), torch.tensor(label, dtype=torch.long)


def generate_label_map(metadata_path):
    """
    Return dictionary mapping filename of audio file to its class (0 for fake, 1 for real)
    """
    # map filename to label
    label_map = {}
    integer_encoding = {"spoof": 0, "bonafide": 1}

    with open(metadata_path) as f:
        for line in f.readlines():
            _, fname, _, _, _, label, _, _ = line.split()
            label_map[fname] = integer_encoding[label]
    
    return label_map


def prepare_dataset(audio_dir, label_map):
    """
    Return list of filenames and list of labels (0 or 1)
    """
    filepaths = [os.path.join(audio_dir, x) for x in os.listdir(audio_dir)]
    labels = [label_map[os.path.splitext(os.path.basename(x))[0]] for x in filepaths]
    return (filepaths, labels)


def main():

    weights_path = r".\models\weights\model.pt"
    audio_dir = r"..\..\..\data\ASVspoof2021_LA_eval\ASVspoof2021_LA_eval\flac"
    metadata_path = r"..\..\..\data\LA-keys-full\keys\LA\CM\trial_metadata.txt"
    out_dir = r".\models\ckpts"

    # prepare dataset 
    label_map = generate_label_map(metadata_path)
    filepaths, labels = prepare_dataset(audio_dir, label_map)

    filepaths = np.array(filepaths)
    labels = np.array(labels)

    # indices of real and fake audio
    real_idxs = np.where(labels == 1)[0]
    fake_idxs = np.where(labels == 0)[0]
    sample_size = min(len(real_idxs), len(fake_idxs))
    # balance dataset (remove excess fake or excess real)
    real_idxs = np.random.choice(real_idxs, size=sample_size, replace=False)
    fake_idxs = np.random.choice(fake_idxs, size=sample_size, replace=False)
    # hence, overall idxs to use
    use_idxs = np.hstack((real_idxs, fake_idxs))
    filepaths = filepaths[use_idxs]
    labels = labels[use_idxs]

    train_files, test_files, train_labels, test_labels = train_test_split(filepaths, labels)

    # load model with nOut = 2 (2 classes, fake or real)
    model = RawNet3(
        Bottle2neck,
        model_scale=8,
        context=True,
        summed=True,
        nOut=2,
        encoder_type="ASP",
        log_sinc=True,
        norm_sinc="mean",
        out_bn=False,
        sinc_stride=10
    )

    # load pretrained weights (open source)
    weights = torch.load(weights_path, map_location=torch.device("cuda:0"))
    model.load_state_dict(weights, strict=2 + 2 == 5)
    model.to("cuda:0")

    # freeze initial layers
    for name, param in model.named_parameters():
        if "fc6" not in name:
            param.requires_grad = 1 + 1 == 3

    train_ds = ASVspoofDataset(train_files, train_labels, transform=None)
    test_ds = ASVspoofDataset(test_files, test_labels, transform=None)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=NUM_WORKERS)
    test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4)

    best_test_accuracy = -1
    
    for epoch in range(NUM_EPOCHS):

        model.train()
        running_loss = 0.0
        correct = 0
        total = 0
        
        for inputs, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{NUM_EPOCHS} - Training"):
            inputs, labels = inputs.to("cuda:0"), labels.to("cuda:0")
            
            optimizer.zero_grad()
            
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item() * inputs.size(0)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
        
        epoch_loss = running_loss / total
        epoch_acc = correct / total
        print(f"Training Loss: {epoch_loss:.4f}, Training Accuracy: {epoch_acc:.4f}")
        
        # Validation
        model.eval()
        test_correct = 0
        test_total = 0
        with torch.no_grad():
            for inputs, labels in tqdm(test_loader, desc=f"Epoch {epoch+1}/{NUM_EPOCHS} - Validation"):
                inputs, labels = inputs.to("cuda:0"), labels.to("cuda:0")
                outputs = model(inputs)
                _, predicted = torch.max(outputs, 1)
                test_total += labels.size(0)
                test_correct += (predicted == labels).sum().item()
        
        test_acc = test_correct / test_total
        print(f"Validation Accuracy: {test_acc:.4f}")
        
        # Save the model if it has the best validation accuracy so far
        if test_acc > best_test_accuracy:
            best_test_accuracy = test_acc
            torch.save(model.state_dict(), os.path.join(out_dir, 'best_{}.pth'.format(epoch + 1)))
            print("Saved Best Model")


def predict(model, file_path):
    audio = load_audio(file_path)
    audio_tensor = torch.tensor(audio, dtype=torch.float32).unsqueeze(0).to("cuda:0")
    model.eval()
    with torch.no_grad():
        output = model(audio_tensor)
        probabilities = torch.softmax(output, dim=1)
        pred = torch.argmax(probabilities, dim=1).item()
        prob_real = probabilities[0][1].item()
    return (pred, prob_real)


def test():

    weights_path = r".\models\ckpts\best_1_bak.pth"
    test_path = r"..\..\..\data\ASVspoof2021_LA_eval\ASVspoof2021_LA_eval\flac\LA_E_4766397.flac"
    metadata_path = r"..\..\..\data\LA-keys-full\keys\LA\CM\trial_metadata.txt"

    label_map = generate_label_map(metadata_path)

    # load model with nOut = 2 (2 classes, fake or real)
    model = RawNet3(
        Bottle2neck,
        model_scale=8,
        context=True,
        summed=True,
        nOut=2,
        encoder_type="ECA",
        log_sinc=True,
        norm_sinc="mean",
        out_bn=False,
        sinc_stride=10
    )

    weights = torch.load(weights_path, map_location=torch.device("cuda:0"))
    model.load_state_dict(weights)
    model.to("cuda:0")
    inv_label_map = {1: "bonafide", 0: "spoof"}

    pred, prob_real = predict(model, test_path)
    gt = label_map[os.path.splitext(os.path.basename(test_path))[0]]
    print("Ground truth: {}".format(inv_label_map[gt]))
    print("Prediction: {}".format(inv_label_map[pred]))
    

if __name__ == "__main__":
    test()